$(document).ready(function () {
  var registeredUsers = [];

  function showError(input, message) {
    $(input).next(".error-text").remove();
    if (message !== "") {
      $(input).after(
        '<small class="error-text text-danger">' + message + "</small>",
      );
    }
  }

  $("#nameInp").on("blur", function () {
    var val = $(this).val();
    if (val.length <= 5) {
      showError(this, "Name must be larger than 5 characters.");
    } else if (/[^a-zA-Z\s]/.test(val)) {
      showError(this, "Name should not contain numbers or symbols.");
    } else {
      showError(this, "");
    }
  });

  $("#emailInp").on("blur", function () {
    var val = $(this).val();
    if (val === "") {
      showError(this, "Your email address is required.");
    } else if (!val.includes("@") || !val.includes(".")) {
      showError(this, "Your email address is invalid.");
    } else {
      showError(this, "");
    }
  });

  $("#passwordInp").on("blur", function () {
    var val = $(this).val();
    var strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])/;

    if (val === "") {
      showError(this, "Password is required.");
    } else if (val.length !== 8) {
      showError(this, "Password must be exactly 8 characters long.");
    } else if (!strongRegex.test(val)) {
      showError(
        this,
        "Must contain 1 capital, 1 simple, 1 number, and 1 symbol.",
      );
    } else {
      showError(this, "");
    }
  });

  $("#signupForm").on("submit", function (e) {
    e.preventDefault();

    if ($(".error-text").length === 0) {
      var newUser = {
        name: $("#nameInp").val(),
        email: $("#emailInp").val(),
        password: $("#passwordInp").val(),
      };

      registeredUsers.push(newUser);

      alert("Sign up successful! User added to array.");
      console.log("Current Users:", registeredUsers);
    } else {
      alert("Please correct the errors before signing up.");
    }
  });
});
