function addShows() {
  let addBox = document.getElementById("showTitle").value;
  let add = addBox.trim();
  let status = document.getElementById("sts");

  if (add !== "" && isNaN(add.charAt(0)) && !/[^A-Za-z0-9]/.test(add)) {
    status.innerHTML = `
       <p class="ps-2 fade show text-success" >TV show <b>${add}</b> has been added.</p>
       `;

    setTimeout(() => {
      status.textContent = "";
      clearInput("showTitle");
    },10000);
  } else {
    status.innerHTML = `
       <p class="ps-2 text-danger fade show" >Invalid TV show name.</p>
       `;

    setTimeout(() => {
      status.textContent = "";
      clearInput("showTitle");
    }, 10000);
  }
}

function clearInput(id) {
  return (document.getElementById(id).value = "");
}