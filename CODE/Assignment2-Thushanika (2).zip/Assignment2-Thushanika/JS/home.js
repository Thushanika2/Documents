const alphabetButtons = document.querySelectorAll("#inputAlpah .btn");

alphabetButtons.forEach((btn) => {
  btn.addEventListener("click", function () {
    const letter = this.innerText.toLowerCase();
    const cards = document.querySelectorAll(".col");

    cards.forEach((card) => {
      const title = card.querySelector(".card-title").innerText.toLowerCase();

      if (letter === "0-9") {
        if (!isNaN(title[0])) {
          card.style.display = "block";
        } else {
          card.style.display = "none";
        }
      } else {
        if (title.startsWith(letter)) {
          card.style.display = "block";
        } else {
          card.style.display = "none";
        }
      }
    });
  });
});

const genreFilter = (category) => {
  const cards = $("#showAssetContainer .col");

  for (let i = 0; i < cards.length; i++) {
    const currentCard = $(cards[i]);

    const cardGenre = currentCard.find(".card").attr("data-genre");

    if (category === "All") {
      currentCard.show();
    } else if (cardGenre === category) {
      currentCard.show();
    } else {
      currentCard.hide();
    }
  }
};

$(document).ready(() => {
  console.log("Page is ready!");

  $("#search").on("keyup", function () {
    const searchText = $(this).val().toLowerCase();
    const cards = $("#showAssetContainer .col");

    for (let i = 0; i < cards.length; i++) {
      const currentCard = $(cards[i]);
      const name = currentCard.find(".card").attr("data-name").toLowerCase();

      if (name.includes(searchText)) {
        currentCard.show();
      } else {
        currentCard.hide();
      }
    }
  });
});

const searchInput = document.getElementById("search");
const cards = document.querySelectorAll(".col");

searchInput.addEventListener("keyup", function () {
  const value = this.value.toLowerCase();

  cards.forEach((card) => {
    const title = card.querySelector(".card-title").innerText.toLowerCase();

    if (title.includes(value)) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
  });
});
