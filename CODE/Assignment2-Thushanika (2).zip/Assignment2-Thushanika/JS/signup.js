$(document).ready(() => {
  const userDatabase = [];

  $("#name").on("blur", function () {
    const nameValue = $(this).val();

    const namePattern = /^[a-zA-Z\s]+$/;

    if (nameValue.length <= 5) {
      alert("Name must be more than 5 characters.");
    } else if (!namePattern.test(nameValue)) {
      alert("Name should not contain numbers or symbols.");
    }
  });

  $("#email").on("blur", function () {
    const emailValue = $(this).val();

    if (
      emailValue !== "" &&
      (!emailValue.includes("@") || !emailValue.includes("."))
    ) {
      alert("Please enter a valid email address.");
    }
  });

  $("#password").on("blur", function () {
    const passValue = $(this).val();

    const strongPattern =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])/;

    if (passValue.length !== 8) {
      alert("Password must be exactly 8 characters long.");
    } else if (!strongPattern.test(passValue)) {
      alert(
        "Password must contain: 1 Capital, 1 Simple, 1 Number, and 1 Symbol.",
      );
    }
  });

  $(".login-container form").on("submit", (event) => {
    event.preventDefault();

    const newUser = {
      name: $("#name").val(),
      email: $("#email").val(),
      password: $("#password").val(),
    };

    userDatabase.push(newUser);

    alert("Sign Up Successful! User object created.");
    console.log("Current Database:", userDatabase);
  });
});
